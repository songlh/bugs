#!/bin/sh

set -e
rm -rf result
