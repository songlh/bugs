typedef struct { char *name; } dummy;
dummy d[] = { {"a"}, {0} };
