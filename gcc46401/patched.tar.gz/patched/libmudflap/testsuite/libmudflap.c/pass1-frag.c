#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main ()
{
int foo [10];
foo[9] = 0;
return 0;
}
