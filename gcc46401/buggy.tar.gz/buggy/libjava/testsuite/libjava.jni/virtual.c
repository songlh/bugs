#include <virtual.h>

JNIEXPORT jboolean JNICALL
Java_virtual_equals (JNIEnv *env, jobject thisv, jobject other)
{
  return JNI_FALSE;
}
