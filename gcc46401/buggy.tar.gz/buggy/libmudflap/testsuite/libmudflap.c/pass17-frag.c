#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main ()
{

strlen("123456789");
return 0;
}
