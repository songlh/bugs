#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main ()
{
char foo[10];
strcpy (foo, "123456789");
return 0;
}
