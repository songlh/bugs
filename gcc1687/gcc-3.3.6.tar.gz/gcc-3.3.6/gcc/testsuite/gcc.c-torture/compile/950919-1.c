#define empty
#if empty#cpu(m68k)
#endif

f (){}
