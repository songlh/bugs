char a[];
f (const int i)
{
  a[i] = 0;
}
