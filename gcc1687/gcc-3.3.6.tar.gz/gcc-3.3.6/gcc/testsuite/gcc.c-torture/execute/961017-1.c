main ()
{
  unsigned char z = 0;

  do ;
  while (--z > 0);
  exit (0);
}
