/* Copyright (C) 2000, 2002 Free Software Foundation, Inc.  */

/* { dg-do preprocess } */
/* { dg-options "-dD -traditional-cpp" } */

/* Test -dD does not fail.  */

#define objlike obj like
#define funlike(like) fun like
