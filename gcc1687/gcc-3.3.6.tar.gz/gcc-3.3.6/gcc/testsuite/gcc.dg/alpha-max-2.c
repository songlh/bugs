/* Test that alpha-max-1.c compiles with optimization.  */
/* { dg-do link { target alpha*-*-* } } */
/* { dg-options "-mcpu=pca56 -O2" } */

#include "alpha-max-1.c"
