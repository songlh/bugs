struct a
{
  struct b t;	/* { dg-error "has incomplete type" } */
};
