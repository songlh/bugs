/* Helper file, included repeatedly by pack-test-1.c.  */

struct SNAME {
  char f0;
  double f1;
  short f2;
  double f3;
  int f4;
  double f5;
  double f6;
  double f7;
};
