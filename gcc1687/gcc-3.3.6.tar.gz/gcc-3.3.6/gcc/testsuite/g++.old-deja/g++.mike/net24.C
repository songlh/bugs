// Build don't link:

    char HexDigit(unsigned char ch) { return ch < 'f'; }
