// Build don't link:

template <class T>
struct S
{
  static const T t = 3;
};

