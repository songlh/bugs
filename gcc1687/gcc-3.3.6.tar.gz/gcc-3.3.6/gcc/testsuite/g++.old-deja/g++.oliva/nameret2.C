// Build don't link:
// Copyright (C) 1999, 2000 Free Software Foundation

// by Alexandre Oliva <oliva@lsd.ic.unicamp.br>

// distilled from libg++'s Integer.cc

// Special g++ Options: -O1 -Wno-deprecated

inline int bar () return r {}

int& foo (int& x) {
  bar ();
  return x;
}
