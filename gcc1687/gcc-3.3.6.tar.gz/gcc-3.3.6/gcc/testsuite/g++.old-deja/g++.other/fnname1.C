// Build don't run:
// Origin: Loren James Rittle <rittle@latour.rsch.comm.mot.com>
// Special g++ Options: -g

int main ()
{
  const char *s = __FUNCTION__;
}
