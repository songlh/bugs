// Build don't link:
// Special g++ Options: -w

struct S
{
  int i : 1756;
};
