package javax.swing.plaf;
import java.awt.Dimension;
/**
 * STUBBED
 */
public class DimensionUIResource extends Dimension implements UIResource
{
  public DimensionUIResource(int w, int h)
  {
    super(w, h);
  }
} // class DimensionUIResource
