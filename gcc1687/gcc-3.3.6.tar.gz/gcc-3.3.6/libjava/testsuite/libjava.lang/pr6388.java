public class pr6388
{
  public static void main (String[] args)
  {
    System.out.println (Integer.MIN_VALUE);
    System.out.println (0x80000000);
    System.out.println (Integer.MIN_VALUE == 0x80000000);
    System.out.println (0x80000000 == 0x80000000);
  }
}
