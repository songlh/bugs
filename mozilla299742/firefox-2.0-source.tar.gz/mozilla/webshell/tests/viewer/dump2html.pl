#!/usr/bin/perl -w
# ***** BEGIN LICENSE BLOCK *****
# Version: MPL 1.1/GPL 2.0/LGPL 2.1
#
# The contents of this file are subject to the Mozilla Public License Version
# 1.1 (the "License"); you may not use this file except in compliance with
# the License. You may obtain a copy of the License at
# http://www.mozilla.org/MPL/
#
# Software distributed under the License is distributed on an "AS IS" basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
# for the specific language governing rights and limitations under the
# License.
#
# The Original Code is dump2html.pl.
#
# The Initial Developer of the Original Code is
# Netscape Communications Corp.
# Portions created by the Initial Developer are Copyright (C) 2002
# the Initial Developer. All Rights Reserved.
#
# Contributor(s):
#   Chris Waterson <waterson@netscape.com>
#
# Alternatively, the contents of this file may be used under the terms of
# either the GNU General Public License Version 2 or later (the "GPL"), or
# the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
# in which case the provisions of the GPL or the LGPL are applicable instead
# of those above. If you wish to allow use of your version of this file only
# under the terms of either the GPL or the LGPL, and not to allow others to
# use your version of this file under the terms of the MPL, indicate your
# decision by deleting the provisions above and replace them with the notice
# and other provisions required by the GPL or the LGPL. If you do not delete
# the provisions above, a recipient may use your version of this file under
# the terms of any one of the MPL, the GPL or the LGPL.
#
# ***** END LICENSE BLOCK *****

#
# Convert a content model dump (e.g., from Viewer's `Debug->Dump
# Content' menu) to HTML.
#

my @tagstack;

sub indent
{
    for (my $count = $#tagstack; $count > 0; --$count) {
        print " ";
    }
}

while (<>) {
    chomp;
    if (/^\s*Text\@0x[[:xdigit:]]+ refcount=\d+<(.*)>$/) {
        # A text node, e.g.
        # `     Text@0xbaf3080 refcount=4<blah blah blah>'
        $_ = $1;

        # Convert newlines, carriage returns, and tabs
        s/\\n/\n/g;
        s/\\t/\t/g;
        s/\\r/\r/g;

        indent;
        print " $_\n";
    }
    elsif (/^\s*([^@]+)\@0x[[:xdigit:]]+(.*) refcount=\d+<$/) {
        # An open tag, e.g.
        # `    a@0xbaf2488 href="index.html" refcount=3<'
        indent;
        print "<$1$2>\n";
        push(@tagstack, $1);
    }
    elsif (/^\s*>$/) {
        # A close tag, e.g., `     >'
        my $tag = pop(@tagstack);
        indent;
        print "</$tag>\n";
    }
}
