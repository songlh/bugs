/******************************************************
Global types for sync

(c) 1995 Innobase Oy

Created 9/5/1995 Heikki Tuuri
*******************************************************/

#ifndef sync0types_h
#define sync0types_h

#define mutex_t ib_mutex_t
typedef struct mutex_struct		mutex_t;


#endif
