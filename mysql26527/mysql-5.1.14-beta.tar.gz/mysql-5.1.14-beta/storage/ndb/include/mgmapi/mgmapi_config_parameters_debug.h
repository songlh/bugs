#ifndef MGMAPI_CONFIG_PARAMTERS_DEBUG_H
#define MGMAPI_CONFIG_PARAMTERS_DEBUG_H

#include "mgmapi_config_parameters.h"

#define CFG_DB_STOP_ON_ERROR_INSERT   1

#endif
