<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple Computer//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>IFPkgDescriptionDeleteWarning</key>
	<string></string>
	<key>IFPkgDescriptionDescription</key>
	<string>MySQL @VERSION@@MYSQL_SERVER_SUFFIX@ for Mac OS X</string>
	<key>IFPkgDescriptionTitle</key>
	<string>MySQL @VERSION@@MYSQL_SERVER_SUFFIX@ for Mac OS X</string>
	<key>IFPkgDescriptionVersion</key>
	<string>@VERSION@@MYSQL_SERVER_SUFFIX@</string>
	</dict>
</plist>
