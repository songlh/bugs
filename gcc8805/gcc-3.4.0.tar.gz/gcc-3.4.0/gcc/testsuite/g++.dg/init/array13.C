template <typename DisjointSet> 
struct test_disjoint_set { 
  static void do_test() 
  { 
    unsigned int elts[] 
        = { 0, 1, 2, 3 }; 
    const int N = sizeof(elts)/sizeof(*elts); 
  } 
}; 
