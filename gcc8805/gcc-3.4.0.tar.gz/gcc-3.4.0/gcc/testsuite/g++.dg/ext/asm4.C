void f ()
{
  __asm__ __volatile__ ("" : : );
}
