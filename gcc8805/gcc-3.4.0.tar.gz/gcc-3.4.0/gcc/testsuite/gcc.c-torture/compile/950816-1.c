f ()
{
  unsigned char b[2];
  float f;
  b[0] = (unsigned char) f / 256;
  return 0;
}
