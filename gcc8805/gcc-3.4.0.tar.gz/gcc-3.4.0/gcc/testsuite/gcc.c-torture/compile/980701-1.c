
short
func(void)
{
	unsigned char x, y;

	return  y | x << 8;
}

