int foo;
int bar;

main ()
{
  return foo + bar;
}
