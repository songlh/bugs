// { dg-do assemble  }

    char HexDigit(unsigned char ch) { return ch < 'f'; }
