// { dg-do assemble  }

template <class T>
void f()
{
  int i[1 << 3];
}
