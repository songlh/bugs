package javax.rmi.CORBA;

/** XXX - Stub till we have org.omg.CORBA */
public class ObjectImpl
{
  public ObjectImpl _orb() { return null; }
  public String object_to_string(ObjectImpl o) 
    throws javax.rmi.BAD_OPERATION { return null; }
}
