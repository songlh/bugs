/******************************************************
Users and sessions global types

(c) 1996 Innobase Oy

Created 6/25/1996 Heikki Tuuri
*******************************************************/

#ifndef usr0types_h
#define usr0types_h

typedef struct sess_struct	sess_t;

#endif
