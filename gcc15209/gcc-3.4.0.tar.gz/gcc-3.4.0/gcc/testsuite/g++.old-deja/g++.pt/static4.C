// { dg-do assemble  }

template <class T>
struct S
{
  static const T t = 3;
};

