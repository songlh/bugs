int *p;

main()
{
  int i = sub ();

  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;
  i = -i;
  if (*p != i)
    goto quit;

  i = -i;
quit:
  sub2 (i);
}
